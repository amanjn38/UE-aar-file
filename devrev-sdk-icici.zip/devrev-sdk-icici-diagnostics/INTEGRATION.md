# DevRev Android SDK 3.0.0-icici-diagnostics-03d115c52: integration note

This build is for diagnostics. It prints extra lines under the `DevRevLogs` Logcat tag so we can see where recording stops.

The zip contains:

```
devrev-maven/ai/devrev/sdk/devrev-sdk/3.0.0-icici-diagnostics-03d115c52/
    devrev-sdk-3.0.0-icici-diagnostics-03d115c52.aar
    devrev-sdk-3.0.0-icici-diagnostics-03d115c52.pom
```

The POM lists the libraries the SDK needs. Gradle reads it and downloads them, so the AAR must be used through this folder and not as a standalone file.

## 1. Place the folder

Copy `devrev-maven` into the root of your Android project, next to `settings.gradle(.kts)`:

```
your-project/
    devrev-maven/
    settings.gradle(.kts)
    app/
```

## 2. Remove the old SDK file

Delete the previous DevRev `.aar` (for example from `app/libs/`) and remove its line from `app/build.gradle(.kts)`, such as `implementation(files("libs/devrev-sdk-....aar"))`. If both remain, the build fails with duplicate classes.

## 3. Add the repository

In `settings.gradle.kts`, inside `dependencyResolutionManagement { repositories { ... } }`:

```kotlin
maven { url = uri("devrev-maven") }
```

Groovy (`settings.gradle`):

```groovy
maven { url "devrev-maven" }
```

If your repositories are declared in the root `build.gradle` under `allprojects { repositories { ... } }`, add the same line there.

## 4. Add the dependency

In `app/build.gradle(.kts)`:

```kotlin
implementation("ai.devrev.sdk:devrev-sdk:3.0.0-icici-diagnostics-03d115c52")
```

Then sync Gradle and rebuild.

The SDK's libraries (SQLDelight, SQLCipher, OkHttp, Tink, WorkManager, kotlinx-serialization and others) come from Google Maven and Maven Central. Your build needs access to those repositories or to your internal mirror of them. If your build forces older versions of any of these libraries, remove that override; the SDK needs `kotlinx-serialization-json` 1.8.1 or later.

## 5. Check network access

The device must reach the DevRev API. The last run failed the token request with `UnknownHostException`, so the host could not be resolved on that network. Please allow the DevRev API domain on the UAT network or proxy.

## 6. Capture logs

1. Start the capture before launching the app: `adb logcat -s DevRevLogs`
2. Launch the app, use it for about a minute, then send it to the background.
3. Share the full output from that one run.

A working run starts with `Diag startup: SDK provider ran` and reaches `Diag capture: first frame saved`.
